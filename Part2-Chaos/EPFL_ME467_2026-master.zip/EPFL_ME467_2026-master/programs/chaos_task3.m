close all; clear; clc

%% inputs
addpath('../functions/')       % folder containing functions
N = 128;                       % spatial resolution
epsilon = 1e-6;                % perturbation amplitude for computing J

% continuation parameters
m = 20;                        % number of continuation steps
% nu0 = ;                      % initial hyperviscosity parameter - to be completed 
nu_final = 3 * nu0 / 4;        % final hyperviscosity parameter

% initialize continuation vectors / matrices
nu_vec = linspace(nu0, nu_final, m + 1);    % vector of hyperviscosity values
v_vec = zeros(round(N / 3), m + 1);         % matrix of converged states
T_vec = zeros(1, m + 1);                    % vector of converged periods
dt_vec = 0.1 * nu_vec;                      % vector of time-steps for time integration
lambda_vec = zeros(1, m + 1);               % vector of max. Floquet multiplier

%% converge and plot the limit cycle
% to be completed ...

%% first continuation step
% to be completed ...

%% subsequent continuation steps
i = 3;
while i <= m + 1
    % to be completed ...
    i = i + 1;
end

% to be completed ...

%% Floquet exponents
for i = 1:(m + 1)
    % to be completed ...
end

% to be completed ...

